import javax.swing.*;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.ArrayList;
import java.util.Objects;

public class MainFrame {
    public static JFrame mainFrame;
    public static JPanel mainPanel;
    public static JTable dataTable;
    public MainFrame(Object[][] userData ) {

        mainFrame = new JFrame();
        mainPanel = new JPanel(new BorderLayout());


        mainFrame.setSize(800, 600);
        mainFrame.setResizable(false);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.add(mainPanel);


        String[] columnNames = {"ID", "Nome", "Cognome", "Data di Nascita", "Piede", "Trofei", "Ritiro", "Ruolo"};
        dataTable = new JTable(userData, columnNames);


        //mainPanel.add(new JScrollPane(dataTable));
        mainPanel.add(dataTable.getTableHeader(), BorderLayout.PAGE_START);
        mainPanel.add(new JScrollPane(dataTable),BorderLayout.CENTER);

        mainFrame.setVisible(true);
    }
}

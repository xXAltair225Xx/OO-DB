import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBMainManager {
    // ... (resto del codice)

    public static Object[][] getUserData() {
        List<Object[]> userDataList = new ArrayList<>();

        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return new Object[0][0];
        }

        // Database connection parameters
        String url = "jdbc:postgresql://localhost:5432/postgres";
        String username = "postgres";
        String password = "Scognamiglio20";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String sqlQuery = "SELECT * FROM giocatore";  // Sostituisci 'your_table_name' con il nome reale della tabella

            try (Statement statement = connection.createStatement()) {
                ResultSet resultSet = statement.executeQuery(sqlQuery);

                while (resultSet.next()) {
                    Object[] rowData = {
                            resultSet.getInt("id_giocatore"),
                            resultSet.getString("nome"),
                            resultSet.getString("cognome"),
                            resultSet.getString("data_Nascita"),
                            resultSet.getString("piede"),
                            resultSet.getInt("trofei"),
                            resultSet.getString("data_ritiro"),
                            resultSet.getString("id_ruolo")
                    };

                    userDataList.add(rowData);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Converte la lista in un array bidimensionale
        Object[][] userData = new Object[userDataList.size()][];
        userDataList.toArray(userData);
        return userData;
    }
}

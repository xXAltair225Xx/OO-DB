import javax.swing.JFrame;

public class Main {
     public static void main(String[] args) {
          // Inizializza il gestore del database e carica le credenziali
          DBLoginManager.loadCredentials();

          // Crea l'istanza di MainFrame
          LoginFrame loginFrame = new LoginFrame();

     }
}
import java.sql.*;
import java.util.HashMap;
   public class DBLoginManager {
        private static HashMap<String, String> userPasswordMap = new HashMap<>();

        public static void loadCredentials() {
            try {
                Class.forName("org.postgresql.Driver");
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
                return;
            }

            // Database connection parameters
            String url = "jdbc:postgresql://localhost:5432/postgres";
            String username = "postgres";
            String password = "Scognamiglio20";

            try (Connection connection = DriverManager.getConnection(url, username, password)) {
                // Execute a simple SQL query
                String sqlQuery = "SELECT * FROM administrator";

                try (Statement statement = connection.createStatement()) {
                    ResultSet resultSet = statement.executeQuery(sqlQuery);

                    // Iterate through the result set and populate the HashMap
                    while (resultSet.next()) {
                        String columnUser = resultSet.getString("adminUsername");
                        String columnPassword = resultSet.getString("adminPassword");
                        userPasswordMap.put(columnUser, columnPassword);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        public static HashMap<String, String> getUserPasswordMap() {
            return userPasswordMap;
        }
   }



import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Player {
    private int player_id;
    private String player_username;
    private String player_password;
    private String player_name;
    private String player_surname;
    private Date birth_date;
    private Date retirement_date;
    private String foot;
    private String[] rolesArray;

    public Player(int player_id, String player_username, String player_password, String player_name, String player_surname, Date birth_date, Date retirement_date, String foot, String[] rolesArray) {
        this.player_id = player_id;
        this.player_username = player_username;
        this.player_password = player_password;
        this.player_name = player_name;
        this.player_surname = player_surname;
        this.birth_date = birth_date;
        this.retirement_date = retirement_date;
        this.foot= foot;
        this.rolesArray = rolesArray;
    }

    public String getUsername() {
        return player_username;
    }

    public String getPassword() {
        return player_password;
    }

    public String getName() {
        return player_name;
    }

    public String getSurname() {
        return player_surname;
    }

    public java.sql.Date getBirthDate() {
      return (java.sql.Date) birth_date;
     }

    public Date getRetireDate() {
        return retirement_date;
    }

    public String getFoot() {
        return foot;
    }

    public String getPlayer_role(){
        return Arrays.toString(rolesArray);
    }

    public int getPlayer_id() {
        return player_id;
    }

    public List<CareerInfo> getCareerInfoList() {
        // Implementa la logica per ottenere la lista delle informazioni sulla carriera dal tuo database
        // Restituisci la lista delle informazioni sulla carriera
        return DBManager.getCareerInfo(getPlayer_id());  // Assumi che ci sia un metodo simile in DBManager
    }
}
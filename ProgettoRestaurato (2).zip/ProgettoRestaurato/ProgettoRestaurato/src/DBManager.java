import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DBManager {
    private static HashMap<String, String> adminCredentialsMap = new HashMap<>();
    private static HashMap<String, String> playerCredentialsMap = new HashMap<>();
    private static HashMap<String, String> coachCredentialsMap = new HashMap<>();
    private static HashMap<String, String> managerCredentialsMap = new HashMap<>();
    private static final String urlSQL = "jdbc:postgresql://138.68.171.83:5432/football_player_manager";
    private static final String usernameSQL = "erteeus";
    private static final String passwordSQL = "442f94bf393acb56271704271bb687c2df";
    private static String querySQL;
    private static String columnAdminLogin;
    private static String columnAdminPassword;
    private static String columnPlayerLogin;
    private static String columnPlayerPassword;
    private static int rowNumber = 20;
    public static int pagNumber = 1;


    public static void loadAdminCredentials() {
        loadCredentials("administrator", "admin_username", "admin_password", "administrator");
    }

    public static void loadPlayerCredentials() {
        loadCredentials("player", "player_username", "player_password", "player");
    }

    public static void loadCoachCredentials() {
        loadCredentials("people", "player_username", "player_password", "coach");
    }

    public static void loadManagerCredentials() {
        loadCredentials("people", "player_username", "player_password", "manager");
    }


    public static void loadCredentials(String tableName, String usernameColumn, String passwordColumn, String userTag) {

        querySQL = "SELECT * FROM " + tableName + ";";
        if ("administrator".equals(tableName)) {
            try (Connection connectionSQL = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL);
                 Statement statementSQL = connectionSQL.createStatement();
                 ResultSet resultSetSQL = statementSQL.executeQuery(querySQL)) {
                while (resultSetSQL.next()) {
                    columnAdminLogin = resultSetSQL.getString(usernameColumn);
                    columnAdminPassword = resultSetSQL.getString(passwordColumn);
                    adminCredentialsMap.put(columnAdminLogin, columnAdminPassword);
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } else if ("player".equals(tableName)) {
            querySQL = "SELECT player_username, player_password FROM player";


            try (Connection connectionSQL = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL);
                 Statement statementSQL = connectionSQL.createStatement();
                 ResultSet resultSetSQL = statementSQL.executeQuery(querySQL)) {
                while (resultSetSQL.next()) {
                    columnPlayerLogin = resultSetSQL.getString(usernameColumn);
                    columnPlayerPassword = resultSetSQL.getString(passwordColumn);
                    playerCredentialsMap.put(columnPlayerLogin, columnPlayerPassword);
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }


    public static List<Player> getPlayer() {
        List<Player> players = new ArrayList<>();

        int pagSumNumber = pagNumber * rowNumber;

        if (pagNumber == 1) {
            pagSumNumber = 0;
        }

        String query = "SELECT player.player_id, player.player_username, player.player_password, player.player_name, player.player_surname, " +
                "player.birth_date, player.retirement_date, player.foot, array_agg(roleList.role_name) AS roles " +
                "FROM player " +
                "LEFT JOIN player_role ON player.player_id = player_role.player_id " +
                "LEFT JOIN roleList ON player_role.role_id = roleList.role_id " +
                "GROUP BY player.player_id LIMIT " + rowNumber + " OFFSET " + pagSumNumber;

        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            // Execute a simple SQL query

            while (resultSet.next()) {
                // Crea un oggetto Giocatore per ogni riga nel risultato
                Player player = new Player(
                        resultSet.getInt("player_id"),
                        resultSet.getString("player_username"),
                        resultSet.getString("player_password"),
                        resultSet.getString("player_name"),
                        resultSet.getString("player_surname"),
                        resultSet.getDate("birth_date"),
                        resultSet.getDate("retirement_date"),
                        resultSet.getString("foot"),
                        (String[]) resultSet.getArray("roles").getArray()
                );

                // Aggiungi il giocatore alla lista
                players.add(player);
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);


        }
        return players;
    }

    //Metodo per modificare il profilo di un giocatore

    public static void modifyPlayerData(String newName, String newSurname, String newPassword) {

//Parametri per la connessione al DB

        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {

// Esegui l'istruzione SQL di UPDATE

            String sqlQuery = "UPDATE player SET player_name = ?, player_surname = ?, player_password = ? WHERE player_username = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setString(1, newName);
                preparedStatement.setString(2, newSurname);
                preparedStatement.setString(3, newPassword);
                preparedStatement.setString(4, WelcomeFrame.username);

                int rowsUpdated = preparedStatement.executeUpdate();

                if (rowsUpdated > 0) {
                    System.out.println("Modifica effettuata con successo!");
                } else {
                    System.out.println("Nessuna modifica effettuata.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    //Interazione con il DB per aggiungere giocatori direttamente dal programma

    public static void addPlayerRole(int player_id, List<Integer> roles) {
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {

            String sqlQuery = "INSERT INTO player_role (player_id, role_id) VALUES(?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                for (int role : roles) {
                    preparedStatement.setInt(1, player_id);
                    preparedStatement.setInt(2, role);
                    preparedStatement.addBatch();
                }

                // Esegui tutte le operazioni di inserimento in una transazione
                connection.setAutoCommit(false);
                preparedStatement.executeBatch();
                connection.commit();
                connection.setAutoCommit(true);

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void addPlayerTrophy(int player_id, List<Integer> trophy) {
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {

            String sqlQuery = "INSERT INTO player_trophy (player_id, trophy_id) VALUES(?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                for (int trofeo : trophy) {
                    preparedStatement.setInt(1, player_id);
                    preparedStatement.setInt(2, trofeo);
                    preparedStatement.addBatch();
                }

                // Esegui tutte le operazioni di inserimento in una transazione
                connection.setAutoCommit(false);
                preparedStatement.executeBatch();
                connection.commit();
                connection.setAutoCommit(true);

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public static void addNewPlayer(String usernameNewPlayer, String passwordNewPlayer, String nome, String cognome, Date dataNascita, String piede, List<Integer> roles, List<Integer> trophy) {
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            // Esegui l'istruzione SQL di INSERT per aggiungere un nuovo giocatore
            String sqlQuery = "INSERT INTO player (player_username, player_password, player_name, player_surname, birth_date, foot) VALUES (?, ? , ? , ? , ? , ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery, Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setString(1, usernameNewPlayer);
                preparedStatement.setString(2, passwordNewPlayer);
                preparedStatement.setString(3, nome);
                preparedStatement.setString(4, cognome);
                preparedStatement.setDate(5, dataNascita);
                preparedStatement.setString(6, piede);

                int rowsInserted = preparedStatement.executeUpdate();

                if (rowsInserted > 0) {
                    // Recupera l'ID del giocatore appena inserito
                    try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            int playerId = generatedKeys.getInt(1);

                            // Aggiungi i ruoli nella tabella player_roles

                            addPlayerRole(playerId, roles);
                            addPlayerTrophy(playerId, trophy);

                            System.out.println("Giocatore aggiunto con successo!");
                        } else {
                            System.out.println("Errore durante il recupero dell'ID del giocatore.");
                        }
                    }
                } else {
                    System.out.println("Errore durante l'aggiunta del giocatore.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    public static HashMap<String, String> getAdminCredentialsMap() {
        return adminCredentialsMap;
    }

    public static HashMap<String, String> getPlayerCredentialsMap() {
        return playerCredentialsMap;
    }

    public static HashMap<String, String> getCoachCredentialsMap() {
        return coachCredentialsMap;
    }

    public static HashMap<String, String> getManagerCredentialsMap() {
        return managerCredentialsMap;
    }


    public static List<CareerInfo> getCareerInfo(int playerId) {
        List<CareerInfo> careerInfoList = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String sqlQuery = "SELECT team.team_name, career.start_date, career.end_date, career.goal_scored, career.match_played, career.trophies_won " +
                    "FROM career " +
                    "JOIN team ON career.team_id = team.team_id " +
                    "WHERE career.player_id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setInt(1, playerId);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String teamName = resultSet.getString("team_name");
                        Date startDate = resultSet.getDate("start_date");
                        Date endDate = resultSet.getDate("end_date");
                        int goals = resultSet.getInt("goal_scored");
                        int matches = resultSet.getInt("match_played");
                        int trophies = resultSet.getInt("trophies_won");

                        CareerInfo careerInfo = new CareerInfo(teamName, startDate, endDate, goals, matches, trophies);
                        careerInfoList.add(careerInfo);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return careerInfoList;
    }

    public static int getPlayerRow() {

        int rowCount = 0;

        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String sqlQuery = "SELECT COUNT(*) FROM player ";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
                ResultSet resultSet = preparedStatement.executeQuery()){

                if (resultSet.next()) {
                    rowCount = resultSet.getInt(1);
                }
            }

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }


            return rowCount;
    }
}





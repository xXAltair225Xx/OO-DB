import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.List;

public class PlayerProfileFrame implements ActionListener {
    private JFrame frame;
    private JPanel panel;
    private JLabel nameLabel;
    private JLabel surnameLabel;
    private JLabel birthDateLabel;
    private JLabel footLabel;
    private JLabel roleLabel;
    private JTable careerTable;
    private JButton backButton;
    private JButton playerModifyButton;
    private static final String[] careerColumnNames = {"Team", "Start Date", "End Date", "Goals", "Matches", "Trophies"};
    private static Object[][] careerData;
    private static JScrollPane careerScrollPane;

    public PlayerProfileFrame(Player player, List<CareerInfo> careerInfoList) {

        careerData = convertCareerInfoToData(careerInfoList);

        frame = new JFrame("Player details");
        panel = new JPanel(new GridLayout(7, 2));
        nameLabel = new JLabel("Name: " + player.getName());
        surnameLabel = new JLabel("Surname: " + player.getSurname());
        birthDateLabel = new JLabel("Birth date: " + formatDate(player.getBirthDate()));
        footLabel = new JLabel("Foot: " + player.getFoot());
        roleLabel = new JLabel("Role: " + player.getPlayer_role());
        careerTable = new JTable(careerData, careerColumnNames);
        backButton = new JButton("Go back");
        playerModifyButton = new JButton("Modify");
        careerScrollPane = new JScrollPane(careerTable);

        frame.setSize(600, 400);  // Dimensioni aumentate per adattarsi alla nuova tabella
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        backButton.addActionListener(this);

        if(WelcomeFrame.role.equals("Admin")){
            panel.add(playerModifyButton);

            playerModifyButton.addActionListener(new ActionListener() {
                @Override

                public void actionPerformed(ActionEvent e) {
                    // Chiudi la finestra di login e apri la schermata iniziale
                    frame.dispose();
                    new PlayerModifyFrame();
                }
            });



        }





        panel.add(nameLabel);
        panel.add(surnameLabel);
        panel.add(birthDateLabel);
        panel.add(footLabel);
        panel.add(roleLabel);
        panel.add(new JLabel());
        panel.add(new JLabel());
        panel.add(careerScrollPane);
        panel.add(backButton);

        frame.add(panel);
        frame.setVisible(true);

    }

    private String formatDate(java.sql.Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(date);
    }

    private Object[][] convertCareerInfoToData(List<CareerInfo> careerInfoList) {
        // Converte la lista di CareerInfo in un array bidimensionale per la tabella
        Object[][] data = new Object[careerInfoList.size()][6];
        for (int i = 0; i < careerInfoList.size(); i++) {
            CareerInfo careerInfo = careerInfoList.get(i);
            data[i][0] = careerInfo.getTeamName();
            data[i][1] = formatDate(careerInfo.getStartDate());
            data[i][2] = formatDate(careerInfo.getEndDate());
            data[i][3] = careerInfo.getGoals();
            data[i][4] = careerInfo.getMatches();
            data[i][5] = careerInfo.getTrophies();
        }
        return data;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == backButton) {
            frame.dispose();
            List<Player> userData = DBManager.getPlayer();
            new MainFrame(userData);
        }
    }
}

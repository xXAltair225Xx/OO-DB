import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import org.mindrot.jbcrypt.*;

public class PlayerModifyFrame {
    private static JFrame frame;
    private static JPanel panel;
    private static JTextField nameTextField;
    private static JTextField surnameTextField;
    private static JTextField usernameTextField;
    private static JPasswordField passwordField;
    private static JLabel usernameLabel;
    private static JLabel nomeLabel;
    private static JLabel cognomeLabel;
    private static JLabel passwordLabel;
    private static JButton modifyButton;
    private static JButton backButton;


    // Aggiungi altri campi necessari per la modifica dei dati

    public PlayerModifyFrame() {

        panel = new JPanel(new GridLayout(5, 2));
        frame = new JFrame("Modify player data");
        nomeLabel = new JLabel("Name:");
        cognomeLabel = new JLabel("Surname:");
        usernameLabel = new JLabel("Username:");
        passwordLabel = new JLabel("Password:");
        modifyButton = new JButton("Modify info");
        backButton = new JButton("Go back");
        nameTextField = new JTextField();
        surnameTextField = new JTextField();
        usernameTextField = new JTextField(WelcomeFrame.username);
        passwordField = new JPasswordField();
        usernameTextField.setEditable(false);

        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);


        // Bottone per modificare i propri dati
        modifyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ottieni i dati inseriti
                String nuovoNome = nameTextField.getText();
                String nuovoCognome = surnameTextField.getText();
                String nuovaPassword = BCrypt.hashpw(passwordField.getText(),BCrypt.gensalt());

                // Esegui la modifica nel database
                DBManager.modifyPlayerData(nuovoNome, nuovoCognome,nuovaPassword);


                // Chiudi la finestra di modifica
                nameTextField.setText("");
                surnameTextField.setText("");
                passwordField.setText("");

                new CheckFrame();

            }
        });

        // Bottone per tornare indietro
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Chiudi la finestra di modifica e torna alla schermata principale del giocatore
                frame.dispose();
                List<Player> userData = DBManager.getPlayer();
                new MainFrame(userData);
                // Puoi aprire la finestra principale del giocatore se necessario
                // Esempio: new PlayerMainFrame(username);
            }
        });

        panel.add(usernameLabel);
        panel.add(usernameTextField);
        panel.add(nomeLabel);
        panel.add(nameTextField);
        panel.add(cognomeLabel);
        panel.add(surnameTextField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(modifyButton);
        panel.add(backButton);


        frame.add(panel);
        frame.setVisible(true);
    }
}

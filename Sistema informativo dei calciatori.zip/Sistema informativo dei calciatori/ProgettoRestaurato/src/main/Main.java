package main;

import gui.WelcomeFrame;

public class Main {
    public static void main(String[] args) {
        // Crea l'istanza di GUI.MainFrame
        new WelcomeFrame();
    }
}
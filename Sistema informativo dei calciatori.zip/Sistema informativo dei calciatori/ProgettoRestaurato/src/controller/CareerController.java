package controller;

import dao.CareerDAO;
import model.CareerInfo;

import java.time.LocalDate;
import java.util.List;

public class CareerController {
    private static CareerDAO careerDAO;

    // Static block to initialize the static field
    static {
        careerDAO = new CareerDAO();
    }

    // Static methods using careerDAO
    public static int addCareer(String username, String team, java.sql.Date startDate, java.sql.Date endDate) {
        return careerDAO.addCareer(username, team, startDate, endDate);
    }

    public static List<CareerInfo> getCareerInfo(int playerId) {
        return careerDAO.getCareerInfo(playerId);
    }

    public static int getCareerId(String username, String teamName, java.sql.Date startDate) {
        return careerDAO.getCareerId(username, teamName, startDate);
    }

    public static String[] getTrophyName() {
        return careerDAO.getTrophyName();
    }
}

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DBManager {
    private static HashMap<String, String> adminCredentialsMap = new HashMap<>();
    private static HashMap<String, String> playerCredentialsMap = new HashMap<>();
    private static HashMap<String, String> coachCredentialsMap = new HashMap<>();
    private static HashMap<String, String> managerCredentialsMap = new HashMap<>();
    private static final String urlSQL = "jdbc:postgresql://localhost:5432/football_player_manager";
    private static final String usernameSQL = "postgres";
    private static final String passwordSQL = "Scognamiglio20";
    private static String querySQL;
    private static String columnAdminLogin;
    private static String columnAdminPassword;
    private static String columnPlayerLogin;
    private static String columnPlayerPassword;
    private static String columnCoachLogin;
    private static String columnCoachPassword;
    private static String columnManagerLogin;
    private static String columnManagerPassword;
    private static int rowNumber = 20;
    public static int pagNumber = 1;



    public static void loadAdminCredentials() {
        loadCredentials("admin_username", "admin_password", "administrator");
    }

    public static void loadPlayerCredentials() {
        loadCredentials("player_username", "player_password", "player");
    }

    public static void loadCoachCredentials() {
        loadCredentials("player_username", "player_password", "coach");
    }

    public static void loadManagerCredentials() {
        loadCredentials("player_username", "player_password", "manager");
    }



    public static void loadCredentials(String usernameColumn, String passwordColumn, String userTag) {


        if ("administrator".equals(userTag)) {
            querySQL = "SELECT * FROM administrator;";
            try (Connection connectionSQL = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL);
                 Statement statementSQL = connectionSQL.createStatement();
                 ResultSet resultSetSQL = statementSQL.executeQuery(querySQL)) {
                while (resultSetSQL.next()) {
                    columnAdminLogin = resultSetSQL.getString(usernameColumn);
                    columnAdminPassword = resultSetSQL.getString(passwordColumn);
                    adminCredentialsMap.put(columnAdminLogin, columnAdminPassword);
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } else if ("player".equals(userTag)) {
            querySQL = "SELECT player_username, player_password FROM player WHERE isCoach = FALSE AND isManager = FALSE";


            try (Connection connectionSQL = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL);
                 Statement statementSQL = connectionSQL.createStatement();
                 ResultSet resultSetSQL = statementSQL.executeQuery(querySQL)) {
                while (resultSetSQL.next()) {
                    columnPlayerLogin = resultSetSQL.getString(usernameColumn);
                    columnPlayerPassword = resultSetSQL.getString(passwordColumn);
                    playerCredentialsMap.put(columnPlayerLogin, columnPlayerPassword);
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        } else if ("coach".equals(userTag)) {
            querySQL = "SELECT player_username, player_password FROM player WHERE isCoach IS TRUE;";


            try (Connection connectionSQL = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL);
                 Statement statementSQL = connectionSQL.createStatement();
                 ResultSet resultSetSQL = statementSQL.executeQuery(querySQL)) {
                while (resultSetSQL.next()) {
                    columnCoachLogin = resultSetSQL.getString(usernameColumn);
                    columnCoachPassword = resultSetSQL.getString(passwordColumn);
                    coachCredentialsMap.put(columnCoachLogin, columnCoachPassword);
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } else if ("manager".equals(userTag)) {
            querySQL = "SELECT player_username, player_password FROM player WHERE isManager IS TRUE;";


            try (Connection connectionSQL = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL);
                 Statement statementSQL = connectionSQL.createStatement();
                 ResultSet resultSetSQL = statementSQL.executeQuery(querySQL)) {
                while (resultSetSQL.next()) {
                    columnManagerLogin = resultSetSQL.getString(usernameColumn);
                    columnManagerPassword = resultSetSQL.getString(passwordColumn);
                    managerCredentialsMap.put(columnManagerLogin, columnManagerPassword);
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }


    public static List<Player> getPlayer() {
        List<Player> players = new ArrayList<>();


        String query = "SELECT player.player_id, player.player_username, player.player_password, player.player_name, player.player_surname, " +
                "player.birth_date, player.retirement_date, player.foot, array_agg(DISTINCT roleList.role_name) AS roles , array_agg(DISTINCT characteristic.characteristic) AS characteristic, player.totalscoredgoal, player.goals_conceded, player.trophies_won " +
                "FROM player " +
                "LEFT JOIN player_role ON player.player_id = player_role.player_id " +
                "LEFT JOIN roleList ON player_role.role_id = roleList.role_id " +
                "LEFT JOIN characteristic_player ON player.player_id = characteristic_player.player_id " +
                "LEFT JOIN characteristic ON characteristic_player.characteristic_id = characteristic.characteristic_id " +
                "GROUP BY player.player_id ";

        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            // Execute a simple SQL query

            while (resultSet.next()) {
                // Crea un oggetto Giocatore per ogni riga nel risultato
                Player player = new Player(
                        resultSet.getInt("player_id"),
                        resultSet.getString("player_username"),
                        resultSet.getString("player_password"),
                        resultSet.getString("player_name"),
                        resultSet.getString("player_surname"),
                        resultSet.getDate("birth_date"),
                        resultSet.getDate("retirement_date"),
                        resultSet.getString("foot"),
                        (String[]) resultSet.getArray("roles").getArray(),
                        (String[]) resultSet.getArray("characteristic").getArray(),
                        resultSet.getInt("totalscoredgoal"),
                        resultSet.getInt("goals_conceded"),
                        resultSet.getInt("trophies_won")
                );
                // Aggiungi il giocatore alla lista
                players.add(player);
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return players;
    }

    //Metodo per modificare il profilo di un giocatore

    public static void deletePlayerRoleOrCharacteristic(int playerId, String campo) {
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {

            String sqlQuery = null;
            if(campo.equals("Role")){
                sqlQuery = "DELETE FROM player_role WHERE player_id = ?";
            } else {
                sqlQuery = "DELETE FROM characteristic_player WHERE player_id = ?";
            }
            try (PreparedStatement psmt = connection.prepareStatement(sqlQuery)) {
                psmt.setInt(1, playerId);
                psmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void addPlayerRole(int playerId, List<Integer> roles) {
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            // Elimina tutti i ruoli associati al giocatore
            String deleteTrophiesQuery = "DELETE FROM player_role WHERE player_id = ?";
            try (PreparedStatement deleteTrophiesStatement = connection.prepareStatement(deleteTrophiesQuery)) {
                deleteTrophiesStatement.setInt(1, playerId);
                deleteTrophiesStatement.executeUpdate();
            }

            // Aggiungi i nuovi ruoli nella tabella player_role
            String addRolesQuery = "INSERT INTO player_role (player_id, role_id) VALUES (?, ?)";
            try (PreparedStatement addRolesStatement = connection.prepareStatement(addRolesQuery)) {
                for (int role : roles) {
                    addRolesStatement.setInt(1, playerId);
                    addRolesStatement.setInt(2, role);
                    addRolesStatement.executeUpdate();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void addPlayerCharacteristics(int playerId, List<Integer> characteristics) {
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {

            String deleteTrophiesQuery = "DELETE FROM characteristic_player WHERE player_id = ?";
            try (PreparedStatement deleteTrophiesStatement = connection.prepareStatement(deleteTrophiesQuery)) {
                deleteTrophiesStatement.setInt(1, playerId);
                deleteTrophiesStatement.executeUpdate();
            }

            String addRolesQuery = "INSERT INTO characteristic_player(player_id, characteristic_id) VALUES (?, ?)";
            try (PreparedStatement addRolesStatement = connection.prepareStatement(addRolesQuery)) {
                for (int characteristic : characteristics) {
                    addRolesStatement.setInt(1, playerId);
                    addRolesStatement.setInt(2, characteristic);
                    addRolesStatement.executeUpdate();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }




    public static void modifyPlayerData(String username, String campo, String nuovo) {
        String sqlQuery = "";
        switch (campo) {
            case "Name":
                sqlQuery = "UPDATE player SET player_name = ? WHERE player_username = ?";
                break;
            case "Surname":
                sqlQuery = "UPDATE player SET player_surname = ? WHERE player_username = ?";
                break;
            case "Password":
                sqlQuery = "UPDATE player SET player_password = ? WHERE player_username = ?";
                break;
            case "Foot":
                sqlQuery = "UPDATE player SET foot = ? WHERE player_username = ?";
                break;

            // Aggiungi altri casi per gli altri campi da modificare
        }

        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL);
             PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
            preparedStatement.setString(1, nuovo);
            preparedStatement.setString(2, username);
            preparedStatement.executeUpdate(); // Esegui la query per effettuare la modifica nel database
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Interazione con il DB per aggiungere giocatori direttamente dal programma

    public static void modifyPlayerRole(int playerId, int roles) {
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {

            // Aggiungi i nuovi ruoli nella tabella player_role
            String addRolesQuery = "INSERT INTO player_role (player_id, role_id) VALUES (?, ?)";
            try (PreparedStatement addRolesStatement = connection.prepareStatement(addRolesQuery)) {

                    addRolesStatement.setInt(1, playerId);
                    addRolesStatement.setInt(2, roles);
                    addRolesStatement.executeUpdate();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void modifyPlayerCharacteristics(int playerId, int characteristics) {
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String addRolesQuery = "INSERT INTO characteristic_player(player_id, characteristic_id) VALUES (?, ?)";
            try (PreparedStatement addRolesStatement = connection.prepareStatement(addRolesQuery)) {
                    addRolesStatement.setInt(1, playerId);
                    addRolesStatement.setInt(2, characteristics);
                    addRolesStatement.executeUpdate();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public static void addPlayerTrophy(int player_id, int trophy, Date year) {
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {

            String sqlQuery = "INSERT INTO player_trophy (player_id, trophy_id, trophy_year) VALUES(?, ?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {

                preparedStatement.setInt(1, player_id);
                preparedStatement.setInt(2, trophy);
                preparedStatement.setDate(3, year);
                preparedStatement.addBatch();


                // Esegui tutte le operazioni di inserimento in una transazione
                connection.setAutoCommit(false);
                preparedStatement.executeBatch();
                connection.commit();
                connection.setAutoCommit(true);

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public static void addNewPlayer(String usernameNewPlayer, String passwordNewPlayer, String nome, String cognome, Date dataNascita, String piede, List<Integer> roles) {
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            // Esegui l'istruzione SQL di INSERT per aggiungere un nuovo giocatore
            String sqlQuery = "INSERT INTO player (player_username, player_password, player_name, player_surname, birth_date, foot) VALUES (?, ? , ? , ? , ? , ?)";


            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery, Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setString(1, usernameNewPlayer);
                preparedStatement.setString(2, passwordNewPlayer);
                preparedStatement.setString(3, nome);
                preparedStatement.setString(4, cognome);
                preparedStatement.setDate(5, dataNascita);
                preparedStatement.setString(6, piede);


                int rowsInserted = preparedStatement.executeUpdate();

                if (rowsInserted > 0) {
                    // Recupera l'ID del giocatore appena inserito
                    try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            int playerId = generatedKeys.getInt(1);

                            // Aggiungi i ruoli nella tabella player_roles

                            addPlayerRole(playerId, roles);
                            new CheckFrame("Success");

                            System.out.println("Giocatore aggiunto con successo!");
                        } else {
                            System.out.println("Errore durante il recupero dell'ID del giocatore.");
                        }
                    }
                } else {
                    System.out.println("Errore durante l'aggiunta del giocatore.");
                }
            }
        } catch (SQLException e) {
            new CheckFrame("This Username is already used");
        }
    }





    public static HashMap<String, String> getAdminCredentialsMap() {
        return adminCredentialsMap;
    }

    public static HashMap<String, String> getPlayerCredentialsMap() {
        return playerCredentialsMap;
    }

    public static HashMap<String, String> getCoachCredentialsMap() {
        return coachCredentialsMap;
    }

    public static HashMap<String, String> getManagerCredentialsMap() {
        return managerCredentialsMap;
    }


    public static List<CareerInfo> getCareerInfo(int playerId) {
        List<CareerInfo> careerInfoList = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String sqlQuery = "SELECT team.team_name, career.start_date, career.end_date, career.goal_scored, career.match_played, career.trophies_won " +
                    "FROM career " +
                    "JOIN team ON career.team_id = team.team_id " +
                    "WHERE career.player_id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setInt(1, playerId);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String teamName = resultSet.getString("team_name");
                        Date startDate = resultSet.getDate("start_date");
                        Date endDate = resultSet.getDate("end_date");
                        int goals = resultSet.getInt("goal_scored");
                        int matches = resultSet.getInt("match_played");
                        int trophies = resultSet.getInt("trophies_won");

                        CareerInfo careerInfo = new CareerInfo(teamName, startDate, endDate, goals, matches, trophies);
                        careerInfoList.add(careerInfo);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return careerInfoList;
    }

    public static int getPlayerRow() {

        int rowCount = 0;

        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String sqlQuery = "SELECT COUNT(*) FROM player ";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                if (resultSet.next()) {
                    rowCount = resultSet.getInt(1);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


        return rowCount;
    }
    public static void playerRetirement(String playerUsername) {
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String sqlQuery = "UPDATE player SET retirement_date = CURRENT_TIMESTAMP WHERE player_username = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                // Set the value for the placeholder
                preparedStatement.setString(1, playerUsername);

                // Execute the update
                preparedStatement.executeUpdate();
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void deletePlayer(int player_id){

        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String sqlQuery =
                    "DELETE FROM player_trophy WHERE player_id = ?;"+
                            " DELETE FROM player_match_stats WHERE player_id = ?;" +
                            " DELETE FROM characteristic_player WHERE player_id = ?;" +
                            " DELETE FROM player_role WHERE player_id = ?;" +
                            " DELETE FROM career WHERE player_id = ?;" +
                            " DELETE FROM player WHERE player_id = ?;" ;

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery) ) {
                // Set the value for the placeholder
                preparedStatement.setInt(1, player_id);
                preparedStatement.setInt(2, player_id);
                preparedStatement.setInt(3, player_id);
                preparedStatement.setInt(4, player_id);
                preparedStatement.setInt(5, player_id);
                preparedStatement.setInt(6,player_id);
                // Execute the update
                preparedStatement.executeUpdate();
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public static Date getRetirementDate(String username){

        String sqlQuery = "SELECT retirement_date FROM player WHERE player_username = ?";
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL);PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {

            preparedStatement.setString(1, username);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {

                if (resultSet.next()){
                    return resultSet.getDate("retirement_date");
                }

            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }


    public static int getPlayerIdByUsername(String username) {
        int playerId = -1; // Valore di default nel caso in cui non venga trovato alcun giocatore

        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String sqlQuery = "SELECT player_id FROM player WHERE player_username = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setString(1, username);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        playerId = resultSet.getInt("player_id");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return playerId;
    }

    public static String[] getRolesName() {
        List<String> roles = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String sqlQuery = "SELECT role_name FROM rolelist";

            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sqlQuery)) {

                while (resultSet.next()) {
                    // Crea un oggetto Giocatore per ogni riga nel risultato

                    String role = resultSet.getString("role_name");



                    // Aggiungi il giocatore alla lista
                    roles.add(role);
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return roles.toArray(new String[0]);
    }

    public static String[] getTrophyName() {
        List<String> trophies = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String sqlQuery = "SELECT trophy_name FROM trophy WHERE individual = TRUE";

            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sqlQuery)) {

                while (resultSet.next()) {
                    // Crea un oggetto Giocatore per ogni riga nel risultato

                    String role = resultSet.getString("trophy_name");



                    // Aggiungi il giocatore alla lista
                    trophies.add(role);
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return trophies.toArray(new String[0]);
    }

    public static String[] getTeamTrophyName() {
        List<String> trophies = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String sqlQuery = "SELECT trophy_name FROM trophy WHERE individual = FALSE";

            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sqlQuery)) {

                while (resultSet.next()) {
                    // Crea un oggetto Giocatore per ogni riga nel risultato

                    String role = resultSet.getString("trophy_name");



                    // Aggiungi il giocatore alla lista
                    trophies.add(role);
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return trophies.toArray(new String[0]);
    }
    public static String[] getCharacteristicName() {
        List<String> characteristic = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String sqlQuery = "SELECT characteristic FROM characteristic";

            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sqlQuery)) {

                while (resultSet.next()) {
                    // Crea un oggetto Giocatore per ogni riga nel risultato

                    String role = resultSet.getString("characteristic");



                    // Aggiungi il giocatore alla lista
                    characteristic.add(role);
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return characteristic.toArray(new String[0]);
    }

    public static String[] getTeamName() {
        List<String> characteristic = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String sqlQuery = "SELECT team_name FROM team";

            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sqlQuery)) {

                while (resultSet.next()) {
                    // Crea un oggetto Giocatore per ogni riga nel risultato

                    String role = resultSet.getString("team_name");

                    // Aggiungi il giocatore alla lista
                    characteristic.add(role);
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return characteristic.toArray(new String[0]);
    }
    public static void setPromote(String promote, int player_id) {

        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {

            if(promote.equals("Coach")){

                String sqlQuery = "UPDATE player SET iscoach = true WHERE player_id = ?";

                try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {

                    preparedStatement.setInt(1, player_id);
                    preparedStatement.executeUpdate();

                }

            } else {
                String sqlQuery = "UPDATE player SET ismanager = true WHERE player_id = ?";

                try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {


                    preparedStatement.setInt(1, player_id);
                    preparedStatement.executeUpdate();


                }
            }



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public static void addCareer(String username, String team, Date startDatePicker, Date endDatePicker) {
        int playerId = getPLayerIdByUsername(username);
        int teamId = getTeamIdByName(team);

        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String query;
            if (endDatePicker != null) {
                query = "INSERT INTO career (player_id, team_id, start_date, end_date) " +
                        "VALUES (?, ?, ?, ?)";
            } else {
                query = "INSERT INTO career (player_id, team_id, start_date) " +
                        "VALUES (?, ?, ?)";
            }
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, playerId);
            pstmt.setInt(2, teamId);
            pstmt.setDate(3, new java.sql.Date(startDatePicker.getTime()));
            if (endDatePicker != null) {
                pstmt.setDate(4, new java.sql.Date(endDatePicker.getTime()));
            }
            pstmt.executeUpdate();
            System.out.println("Career added successfully!");
        } catch (SQLException e) {
            new CheckFrame("Error");
        }
    }

    public static int getTeamIdByCareerId(int careerId) {
        int teamId = -1; // Valore di default nel caso in cui il nome della squadra non venga trovato
        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String query = "SELECT team_id FROM career WHERE career_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, careerId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                teamId = rs.getInt("team_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teamId;
    }
    public static int getTeamIdByName(String teamName) {
        int teamId = -1; // Valore di default nel caso in cui il nome della squadra non venga trovato
        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String query = "SELECT team_id FROM team WHERE team_name = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, teamName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                teamId = rs.getInt("team_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teamId;
    }

    public static int getPLayerIdByUsername(String username) {
        int playerId = -1; // Valore di default nel caso in cui il nome della squadra non venga trovato
        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String query = "SELECT player_id FROM player WHERE player_username = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                playerId = rs.getInt("player_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return playerId;
    }



    public static void updateStartDate(int careerId, LocalDate newStartDate) {
        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String query = "UPDATE career SET start_date = ? WHERE career_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setDate(1, java.sql.Date.valueOf(newStartDate));
                pstmt.setInt(2, careerId);
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateEndDate(int careerId, LocalDate newEndDate) {
        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String query = "UPDATE career SET end_date = ? WHERE career_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setDate(1, java.sql.Date.valueOf(newEndDate));
                pstmt.setInt(2, careerId);
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void endCarrer(int player_id) {
        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String query = "UPDATE career SET end_date = ? WHERE end_date IS NULL AND player_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
                pstmt.setInt(2,player_id);
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static int getCareerId(String username, String teamName, Date startDate) {
        int careerId = -1; // Valore predefinito nel caso in cui non venga trovata una corrispondenza

            String query = "SELECT career_id FROM career WHERE player_id = ? AND team_id = ? AND start_date = ? " ;

            try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL);
                 PreparedStatement pstmt = conn.prepareStatement(query)) {
                // Imposta i parametri della query con i dettagli della carriera
                pstmt.setInt(1, getPLayerIdByUsername(username));
                pstmt.setInt(2, getTeamIdByName(teamName));
                pstmt.setDate(3, new java.sql.Date(startDate.getTime()));

                // Esegui la query
                ResultSet rs = pstmt.executeQuery();

                // Se la query restituisce un risultato, ottieni l'ID della carriera corrispondente
                if (rs.next()) {
                    careerId = rs.getInt("career_id");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        return careerId;
    }


    public static void addTeamTrophy(int team_id, int trophy, Date year) {
        try (Connection connection = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {

            String sqlQuery = "INSERT INTO team_trophy (team_id, trophy_id, trophy_date) VALUES(?, ?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {

                preparedStatement.setInt(1, team_id);
                preparedStatement.setInt(2, trophy);
                preparedStatement.setDate(3, year);
                preparedStatement.addBatch();


                // Esegui tutte le operazioni di inserimento in una transazione
                connection.setAutoCommit(false);
                preparedStatement.executeBatch();
                connection.commit();
                connection.setAutoCommit(true);

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static List<Match> getMatchesForCareerPeriod(int careerId) {
        List<Match> matches = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {

            String query = "SELECT m.*, home_team.team_name AS home_team_name, guest_team.team_name AS guest_team_name " +
                    "FROM match m " +
                    "INNER JOIN career c ON (m.home_team_id = c.team_id OR m.guest_team_id = c.team_id) " +
                    "INNER JOIN team home_team ON m.home_team_id = home_team.team_id " +
                    "INNER JOIN team guest_team ON m.guest_team_id = guest_team.team_id " +
                    "INNER JOIN player_match_stats pms ON m.match_id = pms.match_id " +
                    "WHERE c.career_id = ? " +
                    "AND pms.player_id = (SELECT player_id FROM career WHERE career_id = ?)";

            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, careerId);
            pstmt.setInt(2, careerId);

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String homeTeam = rs.getString("home_team_name");
                String guestTeam = rs.getString("guest_team_name");
                int homeGoals = rs.getInt("home_goals_scored");
                int guestGoals = rs.getInt("guest_goals_scored");
                Date matchDate = rs.getDate("date_match");
                Match match = new Match(homeTeam, guestTeam, homeGoals, guestGoals, matchDate);
                matches.add(match);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return matches;
    }

    public static void insertNewMatch(String homeTeam, String guestTeam, int homeGoals, int guestGoals, Date matchDate) {
        // Implementazione dell'inserimento del nuovo match nel database
        // Utilizza JDBC per interagire con il database e inserire i dati
        int home_team_id = DBManager.getTeamIdByName(homeTeam);
        int guest_team_id = DBManager.getTeamIdByName(guestTeam);

        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String query = "INSERT INTO match (home_team_id, guest_team_id, home_goals_scored, guest_goals_scored, date_match) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, home_team_id);
            pstmt.setInt(2, guest_team_id);
            pstmt.setInt(3, homeGoals);
            pstmt.setInt(4, guestGoals);
            pstmt.setDate(5, new java.sql.Date(matchDate.getTime()));
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static int addNewMatch(int homeTeam, int guestTeam, Date matchDate) {
        int matchId = -1; // Inizializza il matchId a un valore di default

        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String query = "INSERT INTO match (home_team_id, guest_team_id, date_match) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, homeTeam);
            pstmt.setInt(2, guestTeam);
            pstmt.setDate(3, new java.sql.Date(matchDate.getTime()));
            pstmt.executeUpdate();

            // Ottieni l'ID generato per il nuovo match
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                matchId = rs.getInt(1);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return matchId;
    }

    public static String[] getPlayersByTeamId(int teamId) {
        List<String> playerNames = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String query = "SELECT player.player_name, player.player_surname" +
                    " FROM player" +
                    " LEFT JOIN career ON player.player_id = career.player_id" +
                    " WHERE team_id = ? AND end_date IS NULL";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, teamId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String playerName = rs.getString("player_name");
                String playerSurname = rs.getString("player_surname");
                playerNames.add(playerName + " " + playerSurname);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return playerNames.toArray(new String[0]);
    }

    public static void addPlayerMatchStats(int playerId, int teamId, int matchId, int scoredGoals, int roleId) {
        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String query = "INSERT INTO player_match_stats (player_id, team_id, match_id, scored_goals, role_id) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, playerId);
            pstmt.setInt(2, teamId);
            pstmt.setInt(3, matchId);
            pstmt.setInt(4, scoredGoals);
            pstmt.setInt(5, roleId);
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static int getPlayerIdByFullName(String fullName) {
        int playerId = -1; // Valore di default nel caso in cui il giocatore non venga trovato
        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String query = "SELECT player_id FROM player WHERE CONCAT(player_name, ' ', player_surname) = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, fullName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                playerId = rs.getInt("player_id");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return playerId;
    }

    public static int getRoleIdByPlayerId(int playerId) {
        int roleId = -1; // Valore di default nel caso in cui il ruolo non venga trovato
        try (Connection conn = DriverManager.getConnection(urlSQL, usernameSQL, passwordSQL)) {
            String query = "SELECT role_id FROM player_role WHERE player_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, playerId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                roleId = rs.getInt("role_id");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return roleId;
    }
}

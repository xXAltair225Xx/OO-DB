import org.jdesktop.swingx.JXDatePicker;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModifyCareerFrame extends JFrame {
    private static JFrame frame;
    private JComboBox<String> teamComboBox;
    private JXDatePicker startDatePicker;
    private JXDatePicker endDatePicker;
    private JTextField trophiesWonField;


    public ModifyCareerFrame(int careerId) {
        frame = new JFrame();
        frame.setTitle("Modify Career");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(12, 2));


        /* JLabel teamLabel = new JLabel("Team:");
        teamComboBox = new JComboBox<>(DBManager.getTeamName());
        panel.add(teamLabel);
        panel.add(teamComboBox); */

        JLabel startDateLabel = new JLabel("Start Date:");
        startDatePicker = new JXDatePicker();
        panel.add(startDateLabel);
        panel.add(startDatePicker);

        JLabel endDateLabel = new JLabel("End Date:");
        endDatePicker = new JXDatePicker();
        panel.add(endDateLabel);
        panel.add(endDatePicker);


        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveCareerChanges(careerId);
            }
        });
        panel.add(saveButton);

        JButton trophyButton = new JButton("Add Trophy");
        trophyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               new PlayerAddTrophyFrame(WelcomeFrame.username);
            }
        });
        panel.add(trophyButton);

        frame.add(panel);
        frame.setVisible(true);

    }

    private void saveCareerChanges(int careerId) {

       /* String teamName = (String) teamComboBox.getSelectedItem();
        if (teamName != null && !teamName.isEmpty()) {
            DBManager.updateTeam(careerId, teamName);
        } */

        java.util.Date startDate = startDatePicker.getDate();
        if (startDate != null) {
            java.sql.Date sqlStartDate = new java.sql.Date(startDate.getTime());
            DBManager.updateStartDate(careerId, sqlStartDate.toLocalDate());
        }

        java.util.Date endDate = endDatePicker.getDate();
        if (endDate != null) {
            java.sql.Date sqlEndDate = new java.sql.Date(endDate.getTime());
            DBManager.updateEndDate(careerId, sqlEndDate.toLocalDate());
        }


        // Chiudi il frame dopo il salvataggio
        dispose();
    }

}


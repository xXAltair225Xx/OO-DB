import javax.swing.table.AbstractTableModel;
import java.util.List;

public class PlayerTableModel extends AbstractTableModel {
    private List<Player> players;
    private String[] columnNames;

    public PlayerTableModel(List<Player> players, String[] columnNames) {

        this.players = players;
        this.columnNames = columnNames;
    }

    @Override
    public int getRowCount() {
        return players.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Player player = players.get(rowIndex);

        switch (columnIndex) {
            case 0: return player.getNome();
            case 1: return player.getCognome();
            case 2: return player.getDataNascita();
            case 3: return player.getDataRitiro();
            case 4: return player.getPiede();
            case 5: return player.getPlayer_role();

            // Aggiungi altri casi per le colonne rimanenti...
            default: return null;
        }
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }
}
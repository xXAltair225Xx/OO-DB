import org.jdesktop.swingx.JXDatePicker;
import org.mindrot.jbcrypt.BCrypt;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
public class PlayerAddFrame {
    private JFrame frame;
    private JPanel panel;
    private JTextField usernameTextField;
    private JTextField nomeTextField;
    private JTextField cognomeTextField;
    private JXDatePicker datePicker;
    private JPasswordField passwordTextField;
    private JCheckBox[] ruoloCheckBox;
    private JComboBox<String> piedeComboBox;

    private static String[] piede = new String[]{"Right","Left","Ambidexter"};

    private static String[] ruolo = new String[]{"GoalKeeper","Defender","MidFielder","Forward"};
    public PlayerAddFrame() {
        frame = new JFrame("Add player");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        panel = new JPanel(new GridLayout(8, 2));

        JLabel usernameLabel = new JLabel("Username:");
        usernameTextField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        passwordTextField = new JPasswordField();
        JLabel nomeLabel = new JLabel("Name:");
        nomeTextField = new JTextField();
        JLabel cognomeLabel = new JLabel("Surname:");
        cognomeTextField = new JTextField();
        JLabel dataNascitaLabel = new JLabel("Birth date:");
        datePicker = new JXDatePicker();
        JLabel piedeLabel = new JLabel("Foot:");
        piedeComboBox = new JComboBox<>(piede);
        JLabel ruoloLabel = new JLabel("Roles");
        ruoloCheckBox = new JCheckBox[]{new JCheckBox(String.valueOf(ruolo.length))};

        for (int i=0; i< ruolo.length;i++){
            ruoloCheckBox[i]= new JCheckBox(ruolo[i]);
            panel.add(ruoloCheckBox[i]);
        }





        datePicker.setDate(new Date());
        datePicker.setFormats(new SimpleDateFormat("dd/MM/yyyy"));

        JButton addPlayerButton = new JButton("Add");
        addPlayerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                // Ottieni i dati inseriti

                String playerUsername = usernameTextField.getText();
                String playerPassword = passwordTextField.getText();
                String nome = nomeTextField.getText();
                String cognome = cognomeTextField.getText();
                String piede = (String) piedeComboBox.getSelectedItem();
                LocalDate localDate = datePicker.getDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                Date dataNascita = java.sql.Date.valueOf(localDate);


                playerPassword = BCrypt.hashpw(playerPassword, BCrypt.gensalt());


// Esegui l'aggiunta nel database
                DBManager.addNewPlayer(playerUsername, playerPassword, nome, cognome,(java.sql.Date) dataNascita, piede);


                usernameTextField.setText("");
                passwordTextField.setText("");
                nomeTextField.setText("");
                cognomeTextField.setText("");
                new CheckFrame();
            }
        });

        JButton backButton = new JButton("Go back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

// Chiudi il frame di aggiunta e torna alla schermata iniziale
                frame.dispose();
                List<Player> userData = DBManager.getPlayer();
                new MainFrame(userData,"Bella", "Admin");
            }
        });

        panel.add(usernameLabel);
        panel.add(usernameTextField);
        panel.add(passwordLabel);
        panel.add(passwordTextField);
        panel.add(nomeLabel);
        panel.add(nomeTextField);
        panel.add(cognomeLabel);
        panel.add(cognomeTextField);
        panel.add(dataNascitaLabel);
        panel.add(datePicker);
        panel.add(piedeLabel);
        panel.add(piedeComboBox);
        //panel.add(ruoloLabel);
        //panel.add(ruoloComboBox);

        panel.add(addPlayerButton);
        panel.add(backButton);

        frame.add(panel);
        frame.setVisible(true);
    }
}




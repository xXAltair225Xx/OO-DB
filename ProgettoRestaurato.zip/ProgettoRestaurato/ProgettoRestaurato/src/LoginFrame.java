import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Objects;
import java.util.*;
import java.util.List;

import org.mindrot.jbcrypt.*;

public class LoginFrame implements ActionListener {
    private JFrame frame;
    private JPanel panel;
    private JLabel userLabel;
    private JTextField userText;
    private JLabel passwordLabel;
    private JPasswordField passwordText;
    private JButton loginButton;
    private JLabel successLabel;
    private JButton loginBackButton;

    public LoginFrame() {
        frame = new JFrame("Login");
        panel = new JPanel();


        frame.setSize(350, 200);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.add(panel);

        panel.setLayout(null);

        userLabel = new JLabel("User");
        userLabel.setBounds(10, 20, 80, 25);
        panel.add(userLabel);

        userText = new JTextField();
        userText.setBounds(100, 20, 165, 25);
        panel.add(userText);

        passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(10, 50, 80, 25);
        panel.add(passwordLabel);

        passwordText = new JPasswordField();
        passwordText.setBounds(100, 50, 165, 25);
        panel.add(passwordText);

        loginButton = new JButton("Login");
        loginButton.setBounds(180, 90, 100, 25);
        loginButton.addActionListener(this::actionPerformed);
        panel.add(loginButton);

        loginBackButton = new JButton("Main menu");
        loginBackButton.setBounds(40, 90, 100, 25);
        loginBackButton.addActionListener(this::actionPerformed);
        panel.add(loginBackButton);

        successLabel = new JLabel("");
        successLabel.setBounds(10, 120, 165, 25);
        panel.add(successLabel);

        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String user = userText.getText();
        String password = new String(passwordText.getPassword());

        HashMap<String, String> adminPasswordMap = DBManager.getAdminCredentialsMap();
        HashMap<String, String> playerPasswordMap = DBManager.getPlayerCredentialsMap();
        HashMap<String, String> coachPasswordMap = DBManager.getCoachCredentialsMap();
        HashMap<String, String> managerPasswordMap = DBManager.getManagerCredentialsMap();

        String storedPlayerHash = playerPasswordMap.get(user);
        String storedAdminHash = adminPasswordMap.get(user);
        String storedCoachHash = coachPasswordMap.get(user);
        String storedManagerHash = managerPasswordMap.get(user);


        if (e.getSource() == loginButton && storedAdminHash != null && BCrypt.checkpw(password, storedAdminHash)) {
            frame.dispose();
            List<Player> userData = DBManager.getPlayer();
            WelcomeFrame.role = "Admin";
            new MainFrame(userData,"user",WelcomeFrame.role);

        } else if (e.getSource() == loginButton && storedPlayerHash != null && BCrypt.checkpw(password, storedPlayerHash)) {
            frame.dispose();
            List<Player> userData = DBManager.getPlayer();
            WelcomeFrame.role = "Player";
            new MainFrame(userData, "user", WelcomeFrame.role);

        } else if (e.getSource() == loginButton && storedCoachHash != null && BCrypt.checkpw(password, storedCoachHash)) {
            frame.dispose();
            System.out.println("COACH");

        } else if (e.getSource() == loginButton && storedManagerHash != null && BCrypt.checkpw(password, storedManagerHash)) {
            frame.dispose();

        } else if (e.getSource() == loginButton) {
            successLabel.setText("Login failed");

        } else if (e.getSource()== loginBackButton) {
            frame.dispose();
            new WelcomeFrame();
        }


    }
}
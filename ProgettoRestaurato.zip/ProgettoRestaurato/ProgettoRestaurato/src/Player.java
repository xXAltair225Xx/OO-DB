import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Player {
    private String player_username;
    private String player_password;
    private String player_name;
    private String player_surname;
    private Date birth_date;
    private Date retirement_date;
    private String foot;
    private String[] rolesArray;

    // Getter e Setter per gli attributi


    public Player(String player_username, String player_password, String player_name, String player_surname, Date birth_date, Date retirement_date, String foot, String[] rolesArray) {
        this.player_username = player_username;
        this.player_password = player_password;
        this.player_name = player_name;
        this.player_surname = player_surname;
        this.birth_date = birth_date;
        this.retirement_date = retirement_date;
        this.foot= foot;
        this.rolesArray = rolesArray;
    }

    public String getUsername() {
        return player_username;
    }

    public String getPassword() {
        return player_password;
    }

    public String getNome() {
        return player_name;
    }

    public String getCognome() {
        return player_surname;
    }

    public java.sql.Date getDataNascita() {
      return (java.sql.Date) birth_date;
     }

    public Date getDataRitiro() {
        return retirement_date;
    }

    public String getPiede() {
        return foot;
    }

    public String getPlayer_role(){
        return Arrays.toString(rolesArray);
    }

    //public List<Team> getSquadrePartecipanti() {
        // return squadrePartecipanti;
    //}

    //public void aggiungiSquadra(Team squadra) {
      //  squadrePartecipanti.add(squadra);
    //}

    @Override
    public String toString() {
        return "Giocatore{" +
                "username=" + player_username + '\'' +
                ", nome=" + player_name + '\'' +
                ", cognome=" + player_surname + '\'' +
                ", dataNascita=" + birth_date +
                ", dataRitiro=" + retirement_date +
                ", piede=" + foot  +
                ",ruolo=" + Arrays.toString(rolesArray) + '\''+
                '}';
    }


}
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;

public class PlayerProfileFrame implements ActionListener {
    private JFrame frame;
    private JPanel panel;
    private JLabel nameLabel;
    private JLabel surnameLabel;
    private JLabel birthDateLabel;
    private JLabel footLabel;
    private JLabel roleLabel;
    private JButton backButton;



    public PlayerProfileFrame(Player player) {
        frame = new JFrame("Player details");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);

        panel = new JPanel(new GridLayout(6, 2));

        nameLabel = new JLabel("Name: " + player.getNome());
        surnameLabel = new JLabel("Surname: " + player.getCognome());
        birthDateLabel = new JLabel("Birth date: " + formatDate(player.getDataNascita()));
        footLabel = new JLabel("Foot: " + player.getPiede());
        roleLabel = new JLabel("Role: "+ player.getPlayer_role());

        backButton = new JButton("Go back");
        backButton.addActionListener(this);

        panel.add(nameLabel);
        panel.add(surnameLabel);
        panel.add(birthDateLabel);
        panel.add(footLabel);
        panel.add(roleLabel);
        panel.add(backButton);

        frame.add(panel);
        frame.setVisible(true);
    }

    private String formatDate(java.sql.Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(date);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== backButton){
            frame.dispose();
            List<Player> userData = DBManager.getPlayer();
            new MainFrame(userData, "user",WelcomeFrame.role);
        }

    }
}

import org.mindrot.jbcrypt.BCrypt;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.HashMap;

public class CheckFrame{

    private static JFrame frame;
    private static JPanel panel;
    private static JButton button;
    private static JPasswordField passwordCheck;
    private static JLabel label;
    private static JTextField usernameCheck;


    public CheckFrame(String labelValue) {
        frame = new JFrame();
        panel = new JPanel();
        label = new JLabel(labelValue);
        button = new JButton("Ok");
        usernameCheck = new JTextField();
        passwordCheck = new JPasswordField();


        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        panel.setLayout(null);

        label.setBounds(60,20,200,20);
        button.setBounds(85,120,80,20);


        if(labelValue.equals("Are you sure?")){

            passwordCheck.setBounds(85,45,60,20);
            usernameCheck.setBounds(85, 85,60,20);
            button.setText("Confirm");
            panel.add(usernameCheck);
            panel.add(passwordCheck);


            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    HashMap<String, String> playerPasswordMap = DBManager.getPlayerCredentialsMap();
                    String username = usernameCheck.getText();
                    String password = new String(passwordCheck.getPassword());
                    String storedPlayerHash = playerPasswordMap.get(username);

                    if(storedPlayerHash != null && BCrypt.checkpw(password, storedPlayerHash)){
                        DBManager.playerRetirement(username);
                    }
                }
            });


        }


        frame.add(panel);
        panel.add(label);
        panel.add(button);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

        frame.setVisible(true);

    }
}

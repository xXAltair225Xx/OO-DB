import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import org.mindrot.jbcrypt.*;

public class PlayerModifyFrame {
    private static JFrame frame;
    private static JPanel panel;
    private static JTextField nameTextField;
    private static JTextField surnameTextField;
    private static JTextField usernameTextField;
    private static JPasswordField passwordField;
    private static JLabel usernameLabel;
    private static JLabel nameLabel;
    private static JLabel surnameLabel;
    private static JLabel passwordLabel;
    private static JLabel footLabel;
    private static JLabel roleLabel;
    private static JLabel characteristicsLabel;
    private static JComboBox footComboBox;
    private static JList<String> roleList;
    private static JScrollPane roleJScroll;
    private static JList<String> characteristicsList;
    private static JScrollPane characteristicsScrollPane;
    private static JLabel setUpgradeLabel;
    private static JComboBox setUpgradeComboBox;
    private static JButton modifyButton;
    private static JButton backButton;
    private static JButton retireButton;
    private static JButton trophyButton;
    private static JButton careerButton;

    private static String[] foot = new String[]{"Right","Left","Ambidexter"};
    private static String[] upgrade = new String[]{" ", "Coach","Manager"};

    public PlayerModifyFrame() {

        panel = new JPanel(new GridLayout(7, 2));
        frame = new JFrame("Modify player data");
        nameLabel = new JLabel("Name:");
        surnameLabel = new JLabel("Surname:");
        usernameLabel = new JLabel("Username:");
        passwordLabel = new JLabel("Password:");
        footLabel = new JLabel("Foot:");
        modifyButton = new JButton("Modify info");
        backButton = new JButton("Go back");
        retireButton = new JButton("Retire");
        footComboBox = new JComboBox(foot);
        nameTextField = new JTextField();
        surnameTextField = new JTextField();
        usernameTextField = new JTextField(WelcomeFrame.username);
        passwordField = new JPasswordField();
        usernameTextField.setEditable(false);


        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);


        // Bottone per modificare i propri dati
        modifyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ottieni i dati inseriti
                String nuovoNome = nameTextField.getText();
                String nuovoCognome = surnameTextField.getText();
                String nuovaPassword = BCrypt.hashpw(passwordField.getText(),BCrypt.gensalt());

                // Esegui la modifica nel database
                DBManager.modifyPlayerData(nuovoNome, nuovoCognome,nuovaPassword);


                // Chiudi la finestra di modifica
                nameTextField.setText("");
                surnameTextField.setText("");
                passwordField.setText("");

                new CheckFrame("Success");

            }
        });

        // Bottone per tornare indietro
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Chiudi la finestra di modifica e torna alla schermata principale del giocatore
                frame.dispose();
                List<Player> userData = DBManager.getPlayer();
                new MainFrame(userData);
                // Puoi aprire la finestra principale del giocatore se necessario
                // Esempio: new PlayerMainFrame(username);
            }
        });

        retireButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                new CheckFrame("Are you sure?");

            }
        });

        panel.add(usernameLabel);
        panel.add(usernameTextField);
        panel.add(nameLabel);
        panel.add(nameTextField);
        panel.add(surnameLabel);
        panel.add(surnameTextField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(footLabel);
        panel.add(footComboBox);
        panel.add(modifyButton);
        panel.add(backButton);

        if(DBManager.getRetirementDate(WelcomeFrame.username) == null){
            panel.add(retireButton);
        }
        frame.add(panel);
        frame.setVisible(true);
    }


    // COSTRUTTORE PER VISTA ADMIN -------------------------------------------------------------------------------------

    public PlayerModifyFrame(String username) {

        panel = new JPanel(new GridLayout(12, 2));
        frame = new JFrame("Modify player data");
        nameLabel = new JLabel("Name:");
        surnameLabel = new JLabel("Surname:");
        usernameLabel = new JLabel("Username:");
        passwordLabel = new JLabel("Password:");
        roleLabel = new JLabel("Role:");
        footLabel = new JLabel("Foot:");
        characteristicsLabel = new JLabel("Characteristics:");
        setUpgradeLabel = new JLabel("Promote to:");
        modifyButton = new JButton("Modify info");
        backButton = new JButton("Go back");
        retireButton = new JButton("Retire");
        trophyButton = new JButton("Add Trophy");
        careerButton = new JButton("Add Career");
        roleList = new JList<>(DBManager.getRolesName());
        characteristicsList = new JList<>(DBManager.getCharacteristicName());
        footComboBox = new JComboBox(foot);
        roleJScroll = new JScrollPane(roleList);
        characteristicsScrollPane = new JScrollPane(characteristicsList);
        setUpgradeComboBox = new JComboBox<>(upgrade);
        nameTextField = new JTextField();
        surnameTextField = new JTextField();
        usernameTextField = new JTextField(username);
        passwordField = new JPasswordField();
        usernameTextField.setEditable(false);


        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);


        // Bottone per modificare i propri dati
        modifyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ottieni i dati inseriti
                String newName = nameTextField.getText();
                String newSurname = surnameTextField.getText();
                String newPassword = BCrypt.hashpw(passwordField.getText(),BCrypt.gensalt());
                String newFoot = (String) footComboBox.getSelectedItem();

                int[] selectedIndices = roleList.getSelectedIndices();
                List<Integer> selectedRoles = new ArrayList<>();
                for (int selectedIndex : selectedIndices) {
                    selectedRoles.add(selectedIndex + 1);
                }


                int[] selectedCharacteristicsIndices = characteristicsList.getSelectedIndices();
                List<Integer> selectedCharacteristic = new ArrayList<>();
                for (int selectedIndex : selectedCharacteristicsIndices) {
                    selectedCharacteristic.add(selectedIndex + 1);
                }


                String newPromote = (String) setUpgradeComboBox.getSelectedItem();


                // Esegui la modifica nel database
                DBManager.modifyPlayerData(username,newName, newSurname,newPassword, newFoot, selectedRoles, selectedCharacteristic, newPromote);


                // Chiudi la finestra di modifica
                nameTextField.setText("");
                surnameTextField.setText("");
                passwordField.setText("");

                new CheckFrame("Success");

            }
        });

        // Bottone per tornare indietro
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Chiudi la finestra di modifica e torna alla schermata principale del giocatore
                frame.dispose();
                List<Player> userData = DBManager.getPlayer();
                new MainFrame(userData);
                // Puoi aprire la finestra principale del giocatore se necessario
                // Esempio: new PlayerMainFrame(username);
            }
        });

        retireButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                new CheckFrame("Are you sure?");

            }
        });

        trophyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new PlayerAddTrophyFrame(username);
            }
        });

        careerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AddCareerFrame(username);
            }
        });

        panel.add(usernameLabel);
        panel.add(usernameTextField);
        panel.add(nameLabel);
        panel.add(nameTextField);
        panel.add(surnameLabel);
        panel.add(surnameTextField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(footLabel);
        panel.add(footComboBox);
        panel.add(roleLabel);
        panel.add(roleJScroll);
        panel.add(characteristicsLabel);
        panel.add(characteristicsScrollPane);
        panel.add(setUpgradeLabel);
        panel.add(setUpgradeComboBox);
        panel.add(modifyButton);
        panel.add(backButton);
        panel.add(trophyButton);
        panel.add(careerButton);

        if(DBManager.getRetirementDate(WelcomeFrame.username) == null){
            panel.add(retireButton);
        }
        frame.add(panel);
        frame.setVisible(true);
    }



}

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

public class PlayerAddTrophyFrame {
    private static JFrame frame;
    private static JPanel panel;
    private static JPanel buttonPanel;
    private static JButton button;
    private static JLabel trophyLabel;
    private static JComboBox trophyComboBox;

    private static JLabel dateLabel;
    private JComboBox dateComboBox;


    public PlayerAddTrophyFrame(String username) {


        frame = new JFrame();
        panel = new JPanel();
        buttonPanel = new JPanel();
        button = new JButton("Add Trophy");
        trophyLabel = new JLabel("Trophy");
        trophyComboBox = new JComboBox<>(DBManager.getTrophyName());
        dateLabel = new JLabel("Year");
        dateComboBox = new JComboBox<>(getLast100YearsArray());

        frame.setSize(600, 300);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setLayout(new GridLayout(2,1));
        panel.setLayout(new GridLayout(3,2));
        buttonPanel.setLayout(new BorderLayout());



        panel.add(trophyLabel);
        panel.add(trophyComboBox);
        panel.add(dateLabel);
        panel.add(dateComboBox);
        buttonPanel.add(button, BorderLayout.CENTER);
        frame.add(panel);
        frame.add(buttonPanel);
        frame.setVisible(true);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                DBManager.addPlayerTrophy(DBManager.getPlayerIdByUsername(username),trophyComboBox.getSelectedIndex()+1, (Integer) dateComboBox.getSelectedItem());
                new CheckFrame("Success");
            }
        });
    }

    public static Integer[] getLast100YearsArray() {
        Integer[] years = new Integer[100];
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);

        for (int i = 0; i < 100; i++) {
            years[i] = currentYear - i;
        }

        return years;
    }

    public PlayerAddTrophyFrame(int teamId) {


        frame = new JFrame();
        panel = new JPanel();
        buttonPanel = new JPanel();
        button = new JButton("Add Trophy");
        trophyLabel = new JLabel("Trophy");
        trophyComboBox = new JComboBox<>(DBManager.getTeamTrophyName());
        dateLabel = new JLabel("Year");
        dateComboBox = new JComboBox<>(getLast100YearsArray());

        frame.setSize(600, 300);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setLayout(new GridLayout(2,1));
        panel.setLayout(new GridLayout(3,2));
        buttonPanel.setLayout(new BorderLayout());



        panel.add(trophyLabel);
        panel.add(trophyComboBox);
        panel.add(dateLabel);
        panel.add(dateComboBox);
        buttonPanel.add(button, BorderLayout.CENTER);
        frame.add(panel);
        frame.add(buttonPanel);
        frame.setVisible(true);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                DBManager.addTeamTrophy(teamId,trophyComboBox.getSelectedIndex()+1, (Integer) dateComboBox.getSelectedItem());
                new CheckFrame("Success");
            }
        });
    }


}

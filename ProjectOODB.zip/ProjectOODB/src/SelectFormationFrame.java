import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

class SelectFormationFrame {
    private JFrame frame;
    private JPanel panel;
    private JLabel homeTeamLabel;
    private JLabel guestTeamLabel;
    private JLabel matchDateLabel;
    private JComboBox<String>[] homePlayerComboBoxes;
    private JComboBox<String>[] guestPlayerComboBoxes;
    private JTextField[] goalPlayerField;
    private JButton submitButton;

    public SelectFormationFrame(String homeTeam, String guestTeam, Date matchDate) {

        frame = new JFrame("Select Formation");
        panel = new JPanel(new GridLayout(25, 3));

        homeTeamLabel = new JLabel("Home Team: " + homeTeam);
        guestTeamLabel = new JLabel("Guest Team: " + guestTeam);
        matchDateLabel = new JLabel("Match Date: " + matchDate.toString());
        homePlayerComboBoxes = new JComboBox[11];
        guestPlayerComboBoxes = new JComboBox[11];
        goalPlayerField = new JTextField[22];
        submitButton = new JButton("Submit");

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);

        panel.add(homeTeamLabel);
        panel.add(new JLabel());
        panel.add(guestTeamLabel);
        panel.add(new JLabel());
        panel.add(matchDateLabel);
        panel.add(new JLabel());

        for (int i = 0; i < 11; i++) {

            homePlayerComboBoxes[i] = new JComboBox<>();
            guestPlayerComboBoxes[i] = new JComboBox<>();
            goalPlayerField[i] = new JTextField();

            panel.add(new JLabel("Home Player " + (i + 1)));
            panel.add(homePlayerComboBoxes[i]);
            panel.add(goalPlayerField[i]);

            panel.add(new JLabel("Guest Player " + (i + 1)));
            panel.add(guestPlayerComboBoxes[i]);
            panel.add(goalPlayerField[i]);

        }

        panel.add(new JLabel());
        panel.add(new JLabel());
        panel.add(submitButton);

        frame.add(panel);
        frame.setVisible(true);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Implementazione per salvare la formazione nel database
                frame.dispose();
            }
        });
    }
}
public class Main {
    public static void main(String[] args) {
        // Crea l'istanza di MainFrame
        new WelcomeFrame();
    }
}
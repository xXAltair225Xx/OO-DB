import javax.swing.*;

import org.jdesktop.swingx.*;   //Aggiungi scroll pane
import org.jdesktop.swingx.decorator.HighlighterFactory;
import org.jdesktop.swingx.search.TableSearchable;

import java.awt.event.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.text.PlainDocument;
import java.util.List;

public class MainFrame {
    public static JFrame mainFrame;
    public static JPanel mainPanel;
    public static JXTable dataTable;
    private static JButton profileButton;
    private static JButton nextPageButton;
    private static JButton backPageButton;
    private static JButton goTo;
    private static JButton backButton;
    private static JButton playerModifyButton;
    private static JButton playerRetireButton;
    private static JButton addPlayerButton;
    private static JTextField pageCounter;
    private static JLabel pageNumberCounter;
    private static int pageTotalCounter;
    private static JLabel roleLabel;
    private static JLabel usernameLabel;
    private static JComboBox columnFilter;
    private static JTextField searchBar;
    private static JButton filterButton;



    // Creazione delle colonne per la tabella
    String[] columnNames = {"Name", "Surname", "Age", "Retire Date", "Foot", "Roles", "Goal Scored", "Goal Conceded", "Team"};

    public MainFrame(List<Player> players) {

        mainFrame = new JFrame("Welcome " + WelcomeFrame.role);
        mainPanel = new JPanel();
        backPageButton = new JButton("<--");
        goTo = new JButton("Go to");
        pageTotalCounter = DBManager.getPlayerRow() / 20;
        pageCounter = new JTextField();
        nextPageButton = new JButton("-->");
        pageNumberCounter = new JLabel(DBManager.pagNumber + "/" + pageTotalCounter);
        roleLabel = new JLabel("Role: " + WelcomeFrame.role);
        usernameLabel = new JLabel("User: " + WelcomeFrame.username);
        profileButton = new JButton("Visualizza Dettagli Utente");
        backButton = new JButton();
        playerModifyButton = new JButton("Edit Profile");
        playerRetireButton = new JButton("Retirement");
        addPlayerButton = new JButton("Add Player");
        columnFilter = new JComboBox(columnNames);
        searchBar = new JTextField();
        filterButton = new JButton("Search");


        // Creazione del modello della tabella
        PlayerTableModel model = new PlayerTableModel(players, columnNames);
        dataTable = new JXTable(model);

        // Creare un ordinatore per la tabella
        TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(model);
        dataTable.setRowSorter(rowSorter);


        mainFrame.setSize(800, 600);
        mainFrame.setResizable(false);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setLocationRelativeTo(null);
        mainFrame.add(mainPanel);
        goTo.setBounds(240, 500, 100, 25);
        pageCounter.setBounds(350, 500, 20, 25);
        dataTable.getTableHeader().setBounds(45, 60, 700, 20);
        dataTable.setBounds(45, 80, 700, 400);
        pageNumberCounter.setBounds(600, 500, 30, 25);
        roleLabel.setBounds(45, 20, 100, 25);
        usernameLabel.setBounds(150, 20, 100, 25);
        mainPanel.setLayout(null);
        columnFilter.setBounds(300,20,100,25);
        searchBar.setBounds(400,20,100,25);
        filterButton.setBounds(500,20,85,25);


        //Servono ad abilitare la singola selezione delle righe
        ListSelectionModel selectionModel = dataTable.getSelectionModel();
        selectionModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        //Serve ad aggiungere un'ascoltaore per gestire gli eventi di selezione
        selectionModel.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {

                //Serve ad abilitare o disattivare il pulsante della visualizzazione della selezione della riga
                profileButton.setEnabled(!selectionModel.isSelectionEmpty());
            }
        });

        //Aggiunge sfondi alternati alle righe(solo il primo)
        dataTable.setHighlighters(HighlighterFactory.createAlternateStriping());

        //Questo è un mouse listener per gestire i click sulla tabbella
        dataTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {  // Rileva un singolo clic
                    int selectedRow = dataTable.rowAtPoint(e.getPoint());
                    if (selectedRow != -1) {

                        // Ottieni i dati dell'utente selezionato
                        Object[] rowData = new Object[columnNames.length];
                        for (int i = 0; i < columnNames.length; i++) {
                            rowData[i] = dataTable.getValueAt(selectedRow, i);
                        }
                        mainFrame.dispose();
                    }
                }
            }
        });

        // Aggiungi un ascoltatore di eventi alla tabella per gestire la selezione delle righe
        dataTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = dataTable.getSelectedRow();
                if (selectedRow != -1) {
                    // Ottieni il giocatore selezionato
                    Player selectedPlayer = players.get(selectedRow);
                    List<CareerInfo> careerInfoList = selectedPlayer.getCareerInfoList();

                    // Apri la schermata dettagliata
                    new PlayerProfileFrame(selectedPlayer, careerInfoList);
                }
            }
        });


        mainPanel.add(dataTable.getTableHeader());
        mainPanel.add(dataTable);

        nextPageButton = new JButton("-->");
        nextPageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.dispose();
                DBManager.pagNumber++;
                List<Player> userData = DBManager.getPlayer();
                new MainFrame(userData);
            }
        });
        if (DBManager.pagNumber < pageTotalCounter) {
            nextPageButton.setBounds(500, 500, 80, 25);
            mainPanel.add(nextPageButton);
        }


        backPageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.dispose();
                DBManager.pagNumber--;
                List<Player> userData = DBManager.getPlayer();
                new MainFrame(userData);
            }
        });
        if (DBManager.pagNumber > 1) {
            backPageButton.setBounds(400, 500, 80, 25);
            mainPanel.add(backPageButton);
        }

        goTo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                mainFrame.dispose();
                String skipToPage = pageCounter.getText();
                if (isInteger(skipToPage)) {
                    DBManager.pagNumber = getPageNumber(skipToPage, pageTotalCounter);
                } else {
                    new CheckFrame("Invalid Input");
                }
                List<Player> userData = DBManager.getPlayer();
                new MainFrame(userData);

            }
        });

        // Inizialmente disabilitato finché non viene selezionata una riga
        profileButton.setEnabled(false);
        profileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = dataTable.getSelectedRow();
                if (selectedRow != -1) {

                    // Ottieni i dati dell'utente selezionato
                    Object[] rowData = new Object[columnNames.length];
                    for (int i = 0; i < columnNames.length; i++) {
                        rowData[i] = dataTable.getValueAt(selectedRow, i);
                    }
                }
            }
        });

        //Schermata del DB vista dal Guest
        if (WelcomeFrame.role.equals("Guest")) {

            //Creazione bottone per tornare indietro
            backButton.setText("Go back");
            backButton.setBounds(10, 500, 80, 25);
            backButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    // Chiudi la finestra di login e apri la schermata iniziale
                    mainFrame.dispose();
                    new WelcomeFrame();
                }
            });
            mainPanel.add(backButton);
        }

        //Schermata del DB vista dal Giocatore
        else if (WelcomeFrame.role.equals("Player")||WelcomeFrame.role.equals("Coach")||WelcomeFrame.role.equals("Manager")) {

            //Creazione bottone per tornare indietro
            backButton.setText("Log out");
            backButton.setBounds(10, 500, 80, 25);
            backButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Chiudi la finestra di login e apri la schermata iniziale
                    mainFrame.dispose();
                    new LoginFrame();
                }
            });

            //Creazione bottone per modificare i dati del giocatore come Giocatore
            playerModifyButton.setBounds(120, 500, 100, 25);
            playerModifyButton.addActionListener(new ActionListener() {
                @Override

                public void actionPerformed(ActionEvent e) {

                    // Chiudi la finestra di login e apri la schermata iniziale
                    mainFrame.dispose();
                    new PlayerModifyFrame();
                }
            });

            playerRetireButton.setBounds(230, 500, 100, 25);
            playerRetireButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {


                }

            });
            mainPanel.add(backButton);
            mainPanel.add(playerModifyButton);
        }


        //Schermata del DB vista dall'amministratore
        else if (WelcomeFrame.role.equals("Admin")) {

            //Creazione bottone per tornare indietro
            backButton.setText("Log out");
            backButton.setBounds(10, 500, 80, 25);
            backButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Chiudi la finestra di login e apri la schermata iniziale
                    mainFrame.dispose();
                    new LoginFrame();
                }
            });

            //Creazione bottone per aggiungere un nuovo giocatore come Amministratore
            addPlayerButton.setBounds(100, 500, 95, 25);
            addPlayerButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Chiudi la finestra di login e apri la schermata iniziale
                    mainFrame.dispose();
                    new PlayerAddFrame();
                }
            });
            mainPanel.add(addPlayerButton);
            mainPanel.add(backButton);
        }

        mainPanel.add(roleLabel);
        mainPanel.add(usernameLabel);
        mainPanel.add(profileButton);
        mainPanel.add(goTo);
        mainPanel.add(pageCounter);
        mainPanel.add(pageNumberCounter);
        mainPanel.add(columnFilter);
        mainPanel.add(searchBar);
        mainPanel.add(filterButton);
        mainFrame.setVisible(true);

    }


    public static int getPageNumber(String s, int lastPage) {
        try {
            int pageNum = Integer.parseInt(s);
            if (s.length() <= 4 && pageNum > 0 && pageNum <= lastPage) {
                return pageNum;
            } else if (s.length() <= 4 && pageNum > 0 && pageNum > lastPage) {
                return lastPage;
            }
        } catch (NumberFormatException e) {
            new CheckFrame("Invalid Input");
            return 1;
        }
        new CheckFrame("Invalid Input");
        return 1;
    }

    public static boolean isInteger(String s) {
        try {
            Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }
}
